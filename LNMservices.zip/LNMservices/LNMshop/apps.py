from django.apps import AppConfig


class LnmshopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LNMshop'
